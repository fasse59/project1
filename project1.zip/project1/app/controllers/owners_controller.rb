class ownersController < ApplicationController
    def create
      @article = Article.find(params[:article_id])
      @owners = @article.owners.create(owners_params)
      redirect_to article_path(@article)
    end
  
    private
      def owners_params
        params.require(:owners).permit(:name, :age, :status)
      end
  end
  
